#include <iostream>
#include <boost/python.hpp>

// Class Declarations

// BaseClass is not designed to be used by itself
class BaseClass {
    // must be polymorphic--has at least one virtual method
    public:
    virtual void evaluate(void);
};

// Objects A and B are derived from BaseClass
class A : public BaseClass {
    public:
    int index;
    A (int);
    virtual void evaluate(void);
};

class B : public BaseClass {
    public:
    float value;
    B (float);
    virtual void evaluate(void);
};

// This object takes a list of objects and processes them
class ObjectProcessor {
    public:
    void setListByReference (boost::python::list l);
    void setListByPointer (boost::python::list l);    
};

// Class Definitions
using namespace boost::python;

void BaseClass::evaluate (void) {
    std::cout << "Useless base class" << std::endl;
}
A::A (int i) {
    this->index = i;
}
void A::evaluate (void) {
    std::cout << "Index is " << index << std::endl;
}
B::B (float f) {
    this->value = f;
}
void B::evaluate (void) {
    std::cout << "Value is " << value << std::endl;
}

// Methods to get a mixed list of different types of objects from Python
void ObjectProcessor::setListByReference (list l) {
    // This one tries to extract objects using a BaseClass reference
    // It doesn't work
    BaseClass o;
    int len = extract<int>(l.attr("__len__")());
    
    for (int i=0; i<len; i++) {
        std::cout << "Found object type " << typeid(extract <BaseClass&> (l[i])).name() << std::endl;
        o = extract <BaseClass&> (l[i]);
        o.evaluate();
    }
}

void ObjectProcessor::setListByPointer (list l) {
    // This one tries to extract objects using a pointer to BaseClass
    // It works
   BaseClass *o;
   int len = extract<int>(l.attr("__len__")());

   for (int i=0; i<len; i++) {
       std::cout << "Found object type " << typeid( *(extract <const BaseClass*> (l[i])) ).name() << std::endl;
       o = extract <BaseClass*> (l[i]);
       o->evaluate();
   }
}

// Boost.python definitions to expose classes to Python
BOOST_PYTHON_MODULE(DefineClasses) {
    
    class_<BaseClass> ("BaseClass");

    // note how explicit constructor is declared in A and B
    // also note that the we have to tell Boost.python that
    // BaseClass is the base class of A and B
    class_<A, bases<BaseClass> > ("A", init<int>() )
        .def("evaluate", &A::evaluate)
        .def_readwrite("index", &A::index)
    ;
    class_<B, bases<BaseClass> > ("B", init<float>() )
        .def("evaluate", &B::evaluate)
        .def_readwrite("value", &B::value)        
    ;
    class_<ObjectProcessor> ("ObjectProcessor")
        .def("setListByReference", &ObjectProcessor::setListByReference)
        .def("setListByPointer", &ObjectProcessor::setListByPointer)
    ;
}
