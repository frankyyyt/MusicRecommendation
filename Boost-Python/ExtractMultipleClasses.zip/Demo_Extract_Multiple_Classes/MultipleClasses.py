import DefineClasses

# use Python to create some C++ objects
a = DefineClasses.A(3)
b = DefineClasses.B(5.234)

# create a Python list with mixed object types
mixedList = []
mixedList.append(a)
mixedList.append(b)

# create an object to process them
p = DefineClasses.ObjectProcessor()

# try two methods of processing the mixed objects
p.setListByReference(mixedList)     # doesn't work right
p.setListByPointer(mixedList)       # works!

